import {createSlice, PayloadAction} from "@reduxjs/toolkit";
import {UserProfile} from "../../utils/types"


const initialState: UserProfile | null = null;


const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        deleteUser: (state) => initialState,
        changeFirstName: (state, action) => {
            state!.firstName = action.payload;
        },
        changeLastName: (state, action) => {
            state!.lastName = action.payload;
        },
    }
})

export const {deleteUser} = userSlice.actions;
export default userSlice.reducer;