import React from 'react';
import './App.css';
import Guest from "./components/Guest";
import Profile from "./components/Profile";

function App() {
    return (
        <div>
            {/*<Guest/>*/}
            <Profile/>
        </div>
    )
}

export default App;
