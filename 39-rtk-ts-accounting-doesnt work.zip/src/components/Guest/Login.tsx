import React, {useState} from 'react';

const Login = () => {

    const [login, setLogin] = useState("");
    const [password, setPassword] = useState("");


    const handleClickLogin = () => {
        console.log(login, password)
    }

    const handleClickClear = () => {
        setLogin("");
        setPassword("");
    }

    return (
        <div>
            <label>Login:<input onChange={(event) => setLogin(event.target.value.trim())} value={login} type={"text"}/>
            </label>
            <label>Password:<input onChange={(event) => setPassword(event.target.value.trim())} value={password}
                                   type={"password"}/>
            </label>

            <button onClick={handleClickLogin}>Login</button>
            <button onClick={handleClickClear}>Clear</button>
        </div>
    );
};

export default Login;