import Form from "./FormControlled";
import React, {useState} from 'react';
import Weather from "./Weather";
import {API_KEY, BASE_URL} from "../constants/constants";
import FormControlled from "./FormControlled";
import {Info} from "../constants/types";
import {useDispatch} from "react-redux";
import {fetchWeather} from "../actions/weatherAction";

const Data = () => {

    return (<div>
        <FormControlled/>
        <Weather/>
    </div>);
}

export default Data;