import React from 'react';
import {Info, WeatherState} from "../constants/types"
import {useSelector} from "react-redux";

const Weather = () => {

    const info = useSelector((state: WeatherState) => state);

    if (!info.country && !info.message) {
        return (
            <div>
                <p>{"Enter the city:"}</p>
            </div>
        )
    } else if (info.message) {
        return (
            <div>
                <p>{info.message}</p>
            </div>
        )
    } else {
        return (
            <div className='infoWeath'>
                <p>Location: {info!.country}, {info!.city}</p>
                <p>Temp: {Math.round(info!.temperature)}</p>
                <p>Pressure: {info!.pressure}</p>
                <p>Humidity: {info!.humidity}%</p>
                <p>Sunset: {new Date(info!.sunset * 1000).toLocaleTimeString()}</p>
            </div>
        );
    }
};

export default Weather;