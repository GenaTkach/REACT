import React, {ChangeEvent, ChangeEventHandler, Component, useState} from 'react';
import {useDispatch} from "react-redux";
import {fetchWeather} from "../actions/weatherAction";
import {Dispatch} from "redux";



const FormControlled = () => {

    const dispatch: Dispatch<any> = useDispatch();
    const [city, setCity] = useState('');

    const handleClick = () => {
        dispatch(fetchWeather(city));
        setCity('');
    }

    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
        setCity(e.target.value);
    }

    return (<div>
        <input onChange={handleChange} type={"text"} value={city} placeholder={"city"}/>
        <button onClick={handleClick}>Get weather</button>
    </div>);
}

export default FormControlled;