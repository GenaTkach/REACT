import {API_KEY, BASE_URL} from "../constants/constants";
import {Info} from "../constants/types";
import {Dispatch} from "redux";

export const GET_WEATHER = "GET_WEATHER";
export const PENDING_WEATHER = 'PENDING_WEATHER';
export const ERROR_WEATHER = 'ERROR_WEATHER';

export const CLEAN_MSG_WEATHER = 'CLEAN_MSG_WEATHER';



export const getWeather = (weatherInfoObj: Info) => (
    {
        type: GET_WEATHER,
        payload: weatherInfoObj,
    }
)

export const pendingWeather = () => ({
    type: PENDING_WEATHER,
})

export const errorWeather = () => ({
    type: ERROR_WEATHER,
})

export const cleanMsgWeather = () => ({
    type: CLEAN_MSG_WEATHER
})

export const fetchWeather = (city: string) => {
    return async (dispatch: Dispatch) => {
        dispatch(pendingWeather())
        try {
            const response = await fetch(`${BASE_URL}${city}&appid=${API_KEY}&units=metric`);
            const data = await response.json();
            const weatherInfo = {
                country: data.sys.country,
                city: data.name,
                pressure: data.main.pressure,
                temperature: data.main.temp,
                humidity: data.main.humidity,
                sunset: data.sys.sunset
            };
            dispatch(getWeather(weatherInfo));
            dispatch(cleanMsgWeather());
        } catch (error) {
            dispatch(errorWeather());
        }
    }
}