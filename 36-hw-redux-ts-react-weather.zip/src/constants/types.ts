export interface Info {
    country: string;
    city: string;
    pressure: number;
    temperature: number;
    humidity: number;
    sunset: number;
    message?: string;
}

export interface ActionType {
    type: string,
    payload?: Info
}

export type WeatherAction = { type: "GET_WEATHER"; payload: Info }
    | { type: "PENDING_WEATHER" }
    | { type: "ERROR_WEATHER" }
    | { type: "CLEAN_MSG_WEATHER" };

export type WeatherState = {
    country: string;
    city: string;
    pressure: number;
    temperature: number;
    humidity: number;
    sunset: number;
    message?: string;
};