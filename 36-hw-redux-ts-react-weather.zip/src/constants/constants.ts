export const API_KEY = "912969ec9410d959d657540d1560dfa4";

export const BASE_URL = "https://api.openweathermap.org/data/2.5/weather?q=";