import {WeatherAction, WeatherState} from "../constants/types";
import {CLEAN_MSG_WEATHER, ERROR_WEATHER, GET_WEATHER, PENDING_WEATHER} from "../actions/weatherAction";

const initialState: WeatherState = {
    country: "",
    city: "",
    pressure: 0,
    temperature: 0,
    humidity: 0,
    sunset: 0,
    message: "",
};

export const weatherReducer = (state: WeatherState = initialState, action: WeatherAction) => {
    switch (action.type) {
        default:
            return state;
        case GET_WEATHER:
            return {...state, ...action.payload}
        case PENDING_WEATHER:
            return {...state, message: "Pending..."}
        case ERROR_WEATHER:
            return {...state, message: "Error. No such location. Try one more time."}
        case CLEAN_MSG_WEATHER:
            return {...state, message: ""};
    }
}