import React, { useState } from 'react';
import { albums } from '../utils/constants';

const Album = ({ album, text}) => {
    const [isFullSize, setIsFullSize] = useState(false);

    const mouseOutHandler = (e) => {
        e.currentTarget.style.opacity = '1';
    };

    const mouseOverHandler = (e) => {
        e.currentTarget.style.opacity = '0.55';
    };

    const clickHandler = () => {
        setIsFullSize(true);
    };

    const clickCloseFullViewHandler = (e) => {
        setIsFullSize(false);
    };

    return (
        <>
            <img
                onClick={clickHandler}
                onMouseOver={mouseOverHandler}
                onMouseLeave={mouseOutHandler}
                className="col-4 p-1"
                src={album}
                alt="album"
            />
            {isFullSize && (
                <div className="selected-image-overlay" onClick={clickCloseFullViewHandler}>
                    <img src={album} alt="full-size" className="selected-image" />
                    <div className="selected-image-text">
                        <p>Artist : {text.artist}</p>
                        <p>Genre : {text.genre}</p>
                        <p>Year : {text.year}</p>
                    </div>
                </div>
            )}
        </>
    );
};

export default Album;