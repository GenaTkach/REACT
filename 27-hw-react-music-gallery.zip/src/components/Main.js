import React, {useState} from 'react';
import {albums, info} from "../utils/constants";
import Album from "./Album";

const Main = () => {

    return (
        <div className="w-50 mx-auto mt-auto">
            {albums.map((a, index) => (<Album
                    key={index}
                    text={info[index]}
                    album={a}
                />
            ))}
        </div>);
};

export default Main;