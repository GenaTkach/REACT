import album1 from "../images/2016 - 2018.jpeg";
import album2 from "../images/1992day.jpeg";
import album3 from "../images/Moments 002 - KAM BU.jpeg";
import album4 from "../images/aletheia.jpeg";
import album5 from "../images/social distancing from reality.jpeg";
import album6 from "../images/Pray for Paris.jpeg";
import album7 from "../images/Walking Wounded.jpeg";
import album8 from "../images/White tiger.jpeg";
import album9 from "../images/Xylem Tube EP.jpeg";

export const albums = [album1, album2, album3, album4, album5, album6, album7, album8, album9];
export const info = [
        {
            artist: "Nepal",
            genre: "French rap",
            year: 2014
        },
        {
            artist: "Lord Folter",
            genre: "Hip-hop",
            year: 2020
        },
        {
            artist: "KAM-BU & PULLEN",
            genre: "Hip-hop",
            year: 2020
        },
        {
            artist: "O'Flynn",
            genre: "Electronic",
            year: 2019,
        },
        {
            artist: "Meat Computer",
            genre: "New wave hip-hop",
            year: 2020,
        },
        {
            artist: "Westside Gunn",
            genre: "Rap",
            year: 2020,
        },
        {
            artist: "Everything But The Girl",
            genre: "Trip Hop",
            year: 1996,
        },
        {
            artist: "2HOLLIS",
            genre: "Alternative",
            year: 2022,
        },
        {
            artist: "Aphex Twin",
            genre: "EDM",
            year: 1992,
        }
    ]
;
