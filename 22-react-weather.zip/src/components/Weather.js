import React from 'react';

const Weather = () => {
    return (
        <div>
        </div>
    );
};

export default Weather;