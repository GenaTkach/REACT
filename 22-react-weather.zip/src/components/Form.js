import React from 'react';
import Data from "./Data";

const Form = () => {
    const getCity = e => {
        e.preventDefault();
        const API_KEY = "912969ec9410d959d657540d1560dfa4";
        const city = e.currentTarget.city.value;
        fetch("http://api.openweathermap.org/geo/1.0/direct?q=" + city + "&appid=" + API_KEY)
            .then(data => data.json())
            .then(json => fetch("https://api.openweathermap.org/data/2.5/weather?lat=" + json["0"]["lat"] + "&lon=" + json["0"]["lon"] + "&appid=" + API_KEY)
                .then(data => data.json())
                .then(weather => console.log("City = " + json["0"].name + ", Temperature = " + Math.round(eval(weather.main.temp - 273.15)) + ", Humidity = " + weather.main.humidity + "%"))
                .catch(e => console.log(e)))
            .catch(e => console.log(e));
    }

    return (<form onSubmit={getCity}>
        <input type={"text"} name={"city"} placeholder={"city"}/>
        <button type={"submit"}>Get weather</button>
    </form>);
};

export default Form;