export const avatars = ["default" ,"identicon", "monsterid", "wavatar", "retro", "robohash"];
