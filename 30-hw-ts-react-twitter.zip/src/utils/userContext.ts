import React from "react";

const userContextObj = {
    name: "Monster",
    avatar: "https://www.gravatar.com/avatar/0?d=robohash",
    followers: 100,
    following: 1000,
};

export const UserContext = React.createContext(userContextObj);
