import React, {useContext} from 'react';
import {UserContext} from "../utils/userContext";

interface Props{
    size?: string
}

const Avatar = ({size}: Props) => {
    const context =  useContext(UserContext);

    return (
        <img className={`user-avatar ${size ?? ""}`} src={context.avatar} alt={context.name}/>
    );
};

export default Avatar;