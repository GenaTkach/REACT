import React, {useContext} from 'react';
import Avatar from "./Avatar";
import UserStats from "./UserStats";
import {UserContext} from "../utils/userContext";


const Sidebar = () => {
    const context = useContext(UserContext);

    return (
        <div className='sidebar'>
            <UserStats/>
        </div>
    );
};

export default Sidebar;