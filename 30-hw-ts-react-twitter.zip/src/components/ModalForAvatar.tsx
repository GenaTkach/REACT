import React, {useContext, useState} from 'react';
import {UserContext} from "../utils/userContext";
import {avatars} from "../utils/constants";
import {Simulate} from "react-dom/test-utils";

interface Props {
    setShowModal: (isTrue: boolean) => void
}

const ModalForAvatar = ({setShowModal}: Props) => {
    const context = useContext(UserContext);

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Choose avatar</h2>
                <select onChange={(event) => context.avatar = event.target.value}>
                    {avatars.map(a => <option key={a} value={`https://www.gravatar.com/avatar/0?d=${a}`}>{a}</option>)}
                </select>
                <button className="btn btn-danger button" onClick={() => {
                    setShowModal(false);
                }}>Save changes
                </button>
            </div>
        </div>
    );
};

export default ModalForAvatar;