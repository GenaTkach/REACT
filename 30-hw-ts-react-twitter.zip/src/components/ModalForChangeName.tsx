import React, {useContext} from 'react';
import {UserContext} from "../utils/userContext";
import {avatars} from "../utils/constants";

interface Props{
    setShowModal: (isTrue:boolean) => void
}

const ModalForChangeName = ({setShowModal}:Props) => {
    const context = useContext(UserContext);


    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Change name</h2>
                <input onChange={(event) => context.name = event.target.value}>
                </input>
                <button className="btn btn-danger button" onClick={() => {
                    setShowModal(false);
                }}>Save changes
                </button>
            </div>
        </div>
    );
};

export default ModalForChangeName;