import React, {useContext, useEffect, useState} from 'react';
import Avatar from "./Avatar";
import {UserContext} from "../utils/userContext";
import ModalForAvatar from './ModalForAvatar';
import ModalForChangeName from "./ModalForChangeName";


const UserStats = () => {

    const context = useContext(UserContext);
    const [followersAndFollowing, setFollowersAndFollowing] = useState([context.followers, context.following])
    const [showModalForAvatar, setShowModalForAvatar] = useState(false);
    const [showModalForChangeName, setShowModalForChangeName] = useState(false);

    const handleShowModalForAvatar = () => {
        setShowModalForAvatar(true);
    };

    function handleShowModalForChangeName() {
        setShowModalForChangeName(true);
    }

    if (showModalForAvatar) {
        return <ModalForAvatar setShowModal={setShowModalForAvatar}/>
    }


    if (showModalForChangeName) {
         return <ModalForChangeName setShowModal={setShowModalForChangeName}/>
    }


    return (
        <div className="user-stats">
            <div onContextMenu={(event) => {
                event.preventDefault();
                handleShowModalForAvatar();
            }}
                 onClick={handleShowModalForChangeName}>
                <Avatar/>
                {context.name}
            </div>
            <div className="stats">
                <div
                    onClick={() => setFollowersAndFollowing(prevState => {
                        const arr = [...prevState];
                        if (arr[0] > 0) {
                            arr[0]--;
                        }
                        return prevState = arr;
                    })}
                    onContextMenu={(event) => setFollowersAndFollowing(prevState => {
                        event.preventDefault();
                        const arr = [...prevState];
                        arr[0]++;
                        return prevState = arr;
                    })
                    }
                >Followers {followersAndFollowing[0]}</div>

                <div onClick={() => setFollowersAndFollowing(prevState => {
                    const arr = [...prevState];
                    if (arr[1] > 0) {
                        arr[1]--;
                    }
                    return prevState = arr;
                })}
                     onContextMenu={(event) => setFollowersAndFollowing(prevState => {
                         event.preventDefault();
                         const arr = [...prevState];
                         arr[1]++;
                         return prevState = arr;
                     })
                     }>Following {followersAndFollowing[1]}</div>
            </div>
        </div>
    );
};

export default UserStats;