import React, {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import Navigation from "./components/Navigation";
import Body from "./components/Body";
import {UserContext} from "./utils/userContext";

function App() {

    const [name, setName] = useState("Monster");
    const [avatar, setAvatar] = useState("https://www.gravatar.com/avatar/0?d=wavatar");
    const [followers, setFollowers] = useState(100);
    const [following, setFollowing] = useState(1000);

    return (<div className="app">
            <UserContext.Provider value={{
                name: name, avatar: avatar,
                followers: followers, following: following
            }}>
                <Navigation/>
                <Body/>
            </UserContext.Provider>
        </div>
    )
        ;
}

export default App;
