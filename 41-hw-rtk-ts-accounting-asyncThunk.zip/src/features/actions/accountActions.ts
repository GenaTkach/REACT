import {UserRegister} from "../../utils/types";
import {AppDispatch, RootState, store} from "../../app/store";
import {BASE_URL, createToken} from "../../utils/constants";
import {putUser} from "../slices/userSlice";
import tokenSlice, {putToken} from "../slices/tokenSlice";
import {createAsyncThunk} from "@reduxjs/toolkit";


export const registerUser = createAsyncThunk(
    "user/register-user",
    async (user: UserRegister) => {
        const response = await fetch(`${BASE_URL}/user`, {
            method: "POST",
            body: JSON.stringify(user),
            headers: {
                "Content-type": "application/json"
            }
        })
        const data = await response.json();
        const token = createToken(user.login, user.password);
        return {data, token};
    }
)


// export const registerUser = (user: UserRegister) => {
//     return async (dispatch: AppDispatch) => {
//         //TODO pending, error
//         const response = await fetch(`${BASE_URL}/user`, {
//             method: "POST",
//             body: JSON.stringify(user),
//             headers: {
//                 "Content-type": "application/json"
//             }
//         });
//         if (response.ok) {
//             const data = await response.json();
//             dispatch(putUser(data));
//             dispatch(putToken(createToken(user.login, user.password)));
//         } else {
//             throw new Error(response.status.toString());
//         }
//     }
// }

export const fetchUser = createAsyncThunk(
    "user/fetch-user",
    async (token: string) => {
        const response = await fetch(`${BASE_URL}/login`, {
            method: "POST",
            headers: {
                "Authorization": token,
            }
        })
        const data = await response.json();
        return {data, token};
    }
)

// export const fetchUser = (token: string) => {
//     return async (dispatch: AppDispatch) => {
//         //TODO pending, error
//         const response = await fetch(`${BASE_URL}/login`, {
//             method: "POST",
//             headers: {
//                 "Authorization": token,
//             }
//         })
//         if (response.ok) {
//             const data = await response.json();
//             dispatch(putUser(data));
//             dispatch(putToken(token));
//         } else {
//             throw new Error(response.status.toString());
//         }
//     }
// };

export const updateUser = (firstName: string, lastName: string) => {
    return async (dispatch: AppDispatch, getState: typeof store.getState) => {
        //TODO pending, error
        const response = await fetch(`${BASE_URL}/user`, {
            method: "PUT",
            body: JSON.stringify({
                firstName,
                lastName,

            }),
            headers: {
                "Authorization": getState().token,
                "Content-type": "application/json"
            }
        })
        if (response.ok) {
            const data = await response.json();
            dispatch(putUser(data));
        } else {
            throw new Error(response.status.toString());
        }
    }
};

export const changePassword = (password: string, oldPassword: string) => {
    return async (dispatch: AppDispatch, getState: typeof store.getState) => {
        //TODO pending, error
        const response = await fetch(`${BASE_URL}/user/password`, {
            method: "PUT",
            headers: {
                "X-Password": createToken(getState().user.login, oldPassword),
                "Authorization": password,
            }
        })
        if (response.ok) {
            dispatch(putToken(createToken(getState().user.login, password)));
        } else {
            throw new Error(response.status.toString());
        }
    }
}