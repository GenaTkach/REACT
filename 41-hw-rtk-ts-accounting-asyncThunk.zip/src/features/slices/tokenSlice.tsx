import {createSlice, PayloadAction} from "@reduxjs/toolkit";
import {fetchUser, registerUser} from "../actions/accountActions";
import {UserProfile} from "../../utils/types";

const initialState = "";

const tokenSlice = createSlice({
    name: "token",
    initialState,
    reducers: {
        putToken: (state, action: PayloadAction<string>) => {
            return action.payload;
        },
        deleteToken: (state) => {
            return initialState;
        }
    },
    extraReducers: builder => {
        builder
            .addCase(registerUser.fulfilled, (state, action) => {
                return action.payload.token;
            })
            .addCase(fetchUser.fulfilled, (state, action) => action.payload.token)
    }
})

export const {putToken, deleteToken} = tokenSlice.actions
export default tokenSlice.reducer;