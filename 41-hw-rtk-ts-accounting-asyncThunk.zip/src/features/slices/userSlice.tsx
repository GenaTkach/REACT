import {createSlice, PayloadAction} from "@reduxjs/toolkit";
import {UserProfile, UserRegister} from "../../utils/types"
import {fetchUser, registerUser} from "../actions/accountActions";
import {useAppDispatch} from "../../app/hooks";
import {log} from "util";


const initialState: UserProfile | null = {
    login: "",
    firstName: "",
    lastName: "",
    roles: [],
};


const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        deleteUser: (state) => initialState,
        putUser: (state, action: PayloadAction<UserProfile>) => {
            return action.payload;
        },
        changeFirstName: (state, action: PayloadAction<string>) => {
            state.firstName = action.payload;
        },
        changeLastName: (state, action) => {
            state.lastName = action.payload;
        },
        changeLogin: (state, action) => {
            state.login = action.payload;
        },
        addRole: (state, action) => {
            state.roles.push(action.payload);
        },
        removeRole: (state, action) => {
            const index = state.roles.findIndex(action.payload);
            if (index > -1) {
                state.roles.splice(index, 1);
            }
        }
    },
    extraReducers: builder => {
        builder
            .addCase(registerUser.fulfilled, (state, action) => {
                return action.payload.data;
            })
            .addCase(registerUser.pending, (state) => console.log("Pending"))
            .addCase(registerUser.rejected, (state) => console.log("Error"))
            .addCase(fetchUser.fulfilled, (state, action) => {
                return action.payload.data
            })
            .addCase(fetchUser.pending, state => console.log("FetchUser Pending"))
            .addCase(fetchUser.rejected, state => console.log("FetchUser Rejected"))
    }
})

export const {
    deleteUser,
    changeFirstName,
    changeLastName,
    changeLogin,
    addRole,
    removeRole,
    putUser
} = userSlice.actions;
export default userSlice.reducer;