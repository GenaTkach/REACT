export interface UserProfile {
    login: string;
    firstName: string;
    lastName: string;
    roles: string[];
}

export interface ReduxState {
    user: UserProfile;
    token: string;
}

export interface UserRegister {
    login: string;
    firstName: string;
    lastName: string;
    password: string;
}