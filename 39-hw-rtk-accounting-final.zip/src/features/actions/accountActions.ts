import {UserRegister} from "../../utils/types";
import {AppDispatch, RootState, store} from "../../app/store";
import {BASE_URL, createToken} from "../../utils/constants";
import {putUser} from "../slices/userSlice";
import {putToken} from "../slices/tokenSlice";

export const registerUser = (user: UserRegister) => {
    return async (dispatch: AppDispatch) => {
        //TODO pending, error
        const response = await fetch(`${BASE_URL}/user`, {
            method: "POST",
            body: JSON.stringify(user),
            headers: {
                "Content-type": "application/json"
            }
        });
        if (response.ok) {
            const data = await response.json();
            dispatch(putUser(data));
            dispatch(putToken(createToken(user.login, user.password)));
        } else {
            throw new Error(response.status.toString());
        }
    }
}

export const fetchUser = (token: string) => {
    return async (dispatch: AppDispatch) => {
        //TODO pending, error
        const response = await fetch(`${BASE_URL}/login`, {
            method: "POST",
            headers: {
                "Authorization": token,
            }
        })
        if (response.ok) {
            const data = await response.json();
            dispatch(putUser(data));
            dispatch(putToken(token));
        } else {
            throw new Error(response.status.toString());
        }
    }
};

export const updateUser = (firstName: string, lastName: string) => {
    return async (dispatch: AppDispatch, getState: typeof store.getState) => {
        //TODO pending, error
        const response = await fetch(`${BASE_URL}/user`, {
            method: "PUT",
            body: JSON.stringify({
                firstName,
                lastName,

            }),
            headers: {
                "Authorization": getState().token,
                "Content-type": "application/json"
            }
        })
        if (response.ok) {
            const data = await response.json();
            dispatch(putUser(data));
        } else {
            throw new Error(response.status.toString());
        }
    }
};

export const changePassword = (password: string) => {
    return async (dispatch: AppDispatch, getState: typeof store.getState) => {
        //TODO pending, error
        const response = await fetch(`${BASE_URL}/user/password`, {
            method: "PUT",
            headers: {
                "X-Password": password,
                "Authorization": getState().token,
            }
        })
        if (response.ok) {
            dispatch(putToken(createToken(getState().user.login, password)));
        } else {
            throw new Error(response.status.toString());
        }
    }
}