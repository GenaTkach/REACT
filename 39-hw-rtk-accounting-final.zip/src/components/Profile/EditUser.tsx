import React, {useState} from 'react';
import {useAppDispatch} from "../../app/hooks";
import {updateUser} from "../../features/actions/accountActions";

interface Props {
    close: () => void
}

const EditUser = ({close}: Props) => {

    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");

    const dispatch = useAppDispatch();


    const handleClickSave = () => {
        dispatch(updateUser(firstName, lastName));
        close();
    }

    const handleClickClear = () => {
        setFirstName("");
        setLastName("");
    }

    return (
        <div>
            <label>First name:<input onChange={(event) => setFirstName(event.target.value.trim())} value={firstName}
                                     type={"password"}/>
            </label>
            <label>Last name:<input onChange={(event) => setLastName(event.target.value.trim())} value={lastName}
                                    type={"password"}/>
            </label>

            <button onClick={handleClickSave}>Save and Close</button>
            <button onClick={handleClickClear}>Clear</button>
            <button onClick={close}>Close without Save</button>
        </div>
    );
};

export default EditUser;