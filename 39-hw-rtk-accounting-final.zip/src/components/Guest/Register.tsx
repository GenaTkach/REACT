import React, {useState} from 'react';
import {useAppDispatch} from "../../app/hooks";
import {registerUser} from "../../features/actions/accountActions";

const Register = () => {

    const [login, setLogin] = useState("");
    const [password, setPassword] = useState("");
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");

    const dispatch = useAppDispatch();


    const handleClickLogin = () => {
        dispatch(registerUser({login, password, firstName, lastName}));
    }

    const handleClickClear = () => {
        setLogin("");
        setPassword("");
        setFirstName("");
        setLastName("");
    }

    return (
        <div>
            <label>Login:<input onChange={(event) => setLogin(event.target.value.trim())} value={login} type={"text"}/>
            </label>
            <label>Password:<input onChange={(event) => setPassword(event.target.value.trim())} value={password}
                                   type={"password"}/>
            </label>
            <label>First name:<input onChange={(event) => setFirstName(event.target.value.trim())} value={firstName}
                                     type={"password"}/>
            </label>
            <label>Last name:<input onChange={(event) => setLastName(event.target.value.trim())} value={lastName}
                                    type={"password"}/>
            </label>
            <button onClick={handleClickLogin}>Register</button>
            <button onClick={handleClickClear}>Clear</button>
        </div>
    );
};

export default Register;