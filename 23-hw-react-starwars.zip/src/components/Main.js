import React from 'react';
import friend1 from "../images/friend1.jpg";
import friend2 from "../images/friend2.jpg";
import friend3 from "../images/friend3.jpg";
import friend4 from "../images/friend4.jpg";
import friend5 from "../images/friend5.jpg";
import friend6 from "../images/friend6.jpg";
import friend7 from "../images/friend7.jpg";
import friend8 from "../images/friend8.jpg";
import friend9 from "../images/friend9.jpg";
import main from "../images/main.jpg"

class Main extends React.Component {
    render() {
        return (<div>
                <section className="float-start w-25 me-3">
                    <img className="w-100" src={main} alt="hero"></img>
                </section>
                <section className="float-end w-50 row border mx-1 mt-1">
                    <h2 className="col-12 text-center">Dream Team</h2>
                    <img className="col-4 p-1" src={friend1} alt="friend"></img>
                    <img className="col-4 p-1" src={friend2} alt="friend"></img>
                    <img className="col-4 p-1" src={friend3} alt="friend"></img>
                    <img className="col-4 p-1" src={friend4} alt="friend"></img>
                    <img className="col-4 p-1" src={friend5} alt="friend"></img>
                    <img className="col-4 p-1" src={friend6} alt="friend"></img>
                    <img className="bottom-left col-4 p-1" src={friend7} alt="friend"></img>
                    <img className="col-4 p-1" src={friend8} alt="friend"></img>
                    <img className="bottom-right col-4 p-1" src={friend9} alt="friend"></img>
                </section>
                <p className="farGalaxy">It is a period of civil war.
                    Rebel spaceships, striking
                    from a hidden base, have won
                    their first victory against
                    the evil Galactic Empire.

                    During the battle, Rebel
                    spies managed to steal secret
                    plans to the Empire's
                    ultimate weapon, the DEATH
                    STAR, an armored space
                    station with enough power
                    to destroy an entire planet.

                    Pursued by the Empire's
                    sinister agents, Princess
                    Leia races home aboard her
                    starship, custodian of the
                    stolen plans that can save her
                    people and restore
                    freedom to the galaxy....</p>
            </div>);
    }
}

export default Main;