import Header from "./components/Header";
import Main from "./components/Main";
import Footer from "./components/Footer";

import './App.css';

function App() {
    return (
        <div>
            <div className='header'>
                <Header/>
            </div>
            <div className='clearfix'>
                <Main/>
            </div>
            <div className='row align-items-center m-0 footer'>
                <Footer/>
            </div>
        </div>
    );
}

export default App;
