import Form from "./FormControlled";
import React, {useState} from 'react';
import Weather from "./Weather";
import {API_KEY, BASE_URL} from "../constants/constants";
import FormControlled from "./FormControlled";

const Data = () => {

    const [weatherInfo, setWeatherInfo] = useState({});
    const [message, setMessage] = useState("Enter city name");

    const getWeather = async (city) => {
        try {
            const response = await fetch(`${BASE_URL}${city}&appid=${API_KEY}&units=metric`);
            const data = await response.json();
            const weatherInfo = {
                country: data.sys.country,
                city: data.name,
                pressure: data.main.pressure,
                temperature: data.main.temp,
                humidity: data.main.humidity,
                sunset: data.sys.sunset
            };
            setWeatherInfo(weatherInfo);
            setMessage(null);
        } catch (e) {
            {
                console.log(e.message);
                setMessage("Enter correct city name");
            }
        }
    }


        return (<div>
            <FormControlled getWeather={getWeather}/>
            <Weather info={weatherInfo} message={message}/>
        </div>);
}

export default Data;