import React from 'react';
import MainHero from "./MainHero";
import DreamTeam from "./DreamTeam";
import FarGalaxy from "./FarGalaxy";
import Home from "./Home";
import {navItems} from "../utils/constants";
import AboutMe from "./About Me";
import StarWars from "./Star Wars";
import Contacts from "./Contacts";

const Main = ({currentPage}) => {
    switch (currentPage) {
        case navItems[1]:
            return <AboutMe/>
        case navItems[2]:
            return <StarWars/>
        case navItems[3]:
            return <Contacts/>
        default:
            return <Home/>
    }
};

export default Main;