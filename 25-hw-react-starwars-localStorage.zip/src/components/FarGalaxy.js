import React from 'react';
import style from "../css/farGalaxy.module.css"

const BASE_URL = "https://sw-info-api.herokuapp.com/";
const END_POINT = "v1/films/"
const randomNumber = Math.floor(Math.random() * 6) + 1;


class FarGalaxy extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
        }
    }

    componentDidMount() {
        const openingCrawl = sessionStorage.getItem("opening_crawl");
        if (openingCrawl) {
            this.setState({openingCrawl, isLoading: false});
        } else {
            fetch(`${BASE_URL}${END_POINT}${randomNumber}`)
                .then(response => response.json())
                .then(data => {
                    this.setState({openingCrawl: data.opening_crawl, isLoading: false});
                    sessionStorage.setItem("opening_crawl", data.opening_crawl);
                })
                .catch(e => console.log(e));
        }
    }

    render() {
        if (this.state.isLoading) {
            return <div className="d-flex justify-content-center">
                <div className="spinner-grow text-warning m-3" role="status"></div>
            </div>
        } else {
            return (<p className={style.farGalaxy}>{this.state.openingCrawl}</p>);
        }
    }
}

export default FarGalaxy;