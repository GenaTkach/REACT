import React from 'react';
import {DAYS30INMILLISECONDS} from "../utils/constants";


class Contacts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            planets : ['loading...']
        }
    }

    componentDidMount() {
        const planets = JSON.parse(localStorage.getItem('planets'));
        if (planets && Date.now() - localStorage.getItem("creationDateForContacts") < DAYS30INMILLISECONDS) {
            return this.setState({planets});
        } else {
            fetch(`https://sw-info-api.herokuapp.com/v1/planets`)
                .then(response => response.json())
                .then(data => data.map(d => d.name))
                .then(planets => {
                        this.setState({planets})
                        const planetsJSON = JSON.stringify(planets)
                        localStorage.setItem("planets", planetsJSON)
                        localStorage.setItem("creationDateForContacts", Date.now().toString())
                    }
                )
                .catch(e => console.log(e));
        }
    }

    render() {
            return (<div>
                <form>
                    <label>First Name</label>
                    <input type="text" placeholder="Your name.."/>
                    <br/>

                    <label>Last Name</label>
                    <input type="text" placeholder="Your last name.."/>
                    <br/>

                    <label>Planet</label>
                    <select>
                        {this.state.planets.map(planet => <option
                            key={planet}>{planet}</option>)}
                    </select>
                    <br/>

                </form>
            </div>);
        }
}

export default Contacts;