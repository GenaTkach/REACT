import React from 'react';

const NavItem = ({content, changePage}) => {
    return (
        <li onClick={() => changePage(content)} className="nav-item btn btn-danger mx-1">{content}</li>
    );
};

export default NavItem;