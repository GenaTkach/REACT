import React from 'react';
import {type} from "@testing-library/user-event/dist/type";
import {DAYS30INMILLISECONDS} from "../utils/constants";

const BASE_URL = "https://sw-info-api.herokuapp.com/";
const END_POINT = "v1/peoples/1"

class AboutMe extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            hero: {}
        }
    }

    componentDidMount() {
        const hero = JSON.parse(localStorage.getItem('hero'));
        console.log(this.state.hero.name)
        if (hero && Date.now() - localStorage.getItem("creationDateForAboutMe") < DAYS30INMILLISECONDS) {
            this.setState({hero})
        } else {
            fetch(`${BASE_URL}${END_POINT}`)
                .then(response => response.json())
                .then(data => {
                    const hero = {
                        name: data.name,
                        birthYear: data.birth_year,
                        imgUrl: `${BASE_URL}${data.image}`,
                        gender: data.gender,
                        skin_color: data.skin_color,
                        hair_color: data.hair_color,
                        height: data.height,
                        eyeColor: data.eye_color,
                        mass: data.mass,
                    };
                    this.setState({hero})
                    const heroJSON = JSON.stringify(hero)
                    localStorage.setItem('hero', heroJSON);
                    localStorage.setItem("creationDateForAboutMe", Date.now().toString())
                })
                .catch(e => console.log(e));

        }
    }

    render() {
        if (!localStorage.getItem('hero')) {
            return 'loading...';
        } else {
            return (<div>
                {Object.entries(this.state.hero)
                    .map(([key, value]) => {
                        if (key === 'imgUrl') {
                            return <img key={key} src={this.state.hero.imgUrl} alt="hero"/>
                        } else {
                            return <div key={key}>{key.toUpperCase()} : {value}</div>
                        }
                    })}
            </div>);
        }
    }
}

export default AboutMe;