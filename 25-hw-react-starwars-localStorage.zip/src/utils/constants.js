import friend1 from "../images/friend1.jpg";
import friend2 from "../images/friend2.jpg";
import friend3 from "../images/friend3.jpg";
import friend4 from "../images/friend4.jpg";
import friend5 from "../images/friend5.jpg";
import friend6 from "../images/friend6.jpg";
import friend7 from "../images/friend7.jpg";
import friend8 from "../images/friend8.jpg";
import friend9 from "../images/friend9.jpg";

export const imagesOfFriends = [friend1, friend2, friend3, friend4, friend5, friend6, friend7, friend8, friend9];

export const navItems = ["Home", "About me", "Star Wars", "Contacts"];

export const text = `It is a period of civil war.
            Rebel spaceships, striking
            from a hidden base, have won
            their first victory against
            the evil Galactic Empire.

            During the battle, Rebel
            spies managed to steal secret
            plans to the Empire's
            ultimate weapon, the DEATH
            STAR, an armored space
            station with enough power
            to destroy an entire planet.

            Pursued by the Empire's
            sinister agents, Princess
            Leia races home aboard her
            starship, custodian of the
            stolen plans that can save her
            people and restore
            freedom to the galaxy....`

export const textForStarWarsComponent = `Star Wars is a science fiction franchise that was created by filmmaker George Lucas in 1977 with the release of the first film, now known as Star Wars Episode IV: A New Hope. The franchise has since expanded to include numerous films, television shows, novels, comic books, video games, and other media.

The Star Wars universe is set in a distant galaxy and follows the adventures of a diverse cast of characters, including Jedi Knights, Sith Lords, smugglers, bounty hunters, and droids, among others. The story primarily revolves around the conflict between the Jedi, who are trained in the use of the Force, a mystical energy field that permeates the universe, and the Sith, who seek to use the Force for their own personal gain.

The original trilogy of films, which includes A New Hope, The Empire Strikes Back, and Return of the Jedi, focuses on the hero's journey of Luke Skywalker, a young farm boy who becomes a Jedi Knight and helps overthrow the evil Galactic Empire.

The prequel trilogy, which includes The Phantom Menace, Attack of the Clones, and Revenge of the Sith, takes place before the events of the original trilogy and explores the backstory of characters like Anakin Skywalker (who later becomes Darth Vader) and Obi-Wan Kenobi.

The sequel trilogy, which includes The Force Awakens, The Last Jedi, and The Rise of Skywalker, takes place after the events of the original trilogy and features a new cast of characters, including Rey, Finn, and Poe Dameron, as they battle the First Order, a new iteration of the Empire.

In addition to the films, the Star Wars franchise has also produced numerous television shows, including The Clone Wars, Rebels, and The Mandalorian, as well as an extensive collection of books, comics, and video games that expand on the Star Wars universe and its characters.`

export const DAYS30INMILLISECONDS = 2592000000;
