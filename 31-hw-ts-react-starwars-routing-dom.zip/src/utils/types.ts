export interface Hero {
    [key: string]: string
}

export interface Item {
    route: string;
    title: string;
}

export const characters = new Map<string, number>([
    ["R2D2", 3],
    ["C3-PO", 4],
    ["EWOK", 6],
    ["CHEWBACCA", 13],
    ["HAN_SOLO", 14],
    ["LEIA", 5],
    ["FALCON", 11],
    ["OBI-WAN", 10],
    ["YODA", 0]
]);