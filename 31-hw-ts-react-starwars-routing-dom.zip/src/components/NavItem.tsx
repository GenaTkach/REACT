import React, {useContext} from 'react';
import {Item} from "../utils/types";
import {Link} from "react-router-dom";

interface Props {
    content: Item;
}

const NavItem = ({content}: Props) => {
    return (
        <li>
            <Link className="nav-item btn btn-danger mx-1" to={content.route}>{content.title}</Link>
        </li>
    );
};

export default NavItem;