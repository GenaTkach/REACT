import React, {useContext} from 'react';
import MainHero from "./MainHero";
import DreamTeam from "./DreamTeam";
import FarGalaxy from "./FarGalaxy";
import Home from "./Home";
import {navItems} from "../utils/constants";
import AboutMe from "./About Me";
import StarWars from "./Star Wars";
import Contacts from "./Contacts";
import {Route, Routes} from "react-router-dom";

const Main = () => {

    return (
        <Routes>/
            {["/", navItems[0].route].map(p => <Route key={p} path={p} element={<Home/>}/>)}
            {[navItems[1].route, `${navItems[1].route}/:heroId`].map(p => <Route key={p} path={p}
                                                                                 element={<AboutMe/>}/>)}
            <Route path={navItems[1].route} element={<AboutMe/>}/>
            <Route path={navItems[2].route} element={<StarWars/>}/>
            <Route path={navItems[3].route} element={<Contacts/>}/>
        </Routes>
    )
};

export default Main;