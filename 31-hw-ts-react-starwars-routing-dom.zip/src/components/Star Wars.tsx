import React from 'react';
import {textForStarWarsComponent} from "../utils/constants";

const StarWars = () => {
    return (
        <div>
            <p className="textForStarWarsComponent">{textForStarWarsComponent}</p>
        </div>
    );
};

export default StarWars;