import React, {useEffect, useState} from 'react';
import style from "../css/farGalaxy.module.css"

const BASE_URL = "https://sw-info-api.herokuapp.com/";
const END_POINT = "v1/films/"
const randomNumber = Math.floor(Math.random() * 6) + 1;


const FarGalaxy = () => {

    const [openingCrawl, setOpeningCrawl] = useState('');

    useEffect(() => {
        const openingCrawl = sessionStorage.getItem("opening_crawl")!;
        if (openingCrawl) {
            setOpeningCrawl(openingCrawl);
        } else {
            fetch(`${BASE_URL}${END_POINT}${randomNumber}`)
                .then(response => response.json())
                .then(data => {
                    setOpeningCrawl(data.opening_crawl);
                    sessionStorage.setItem("opening_crawl", data.opening_crawl);
                })
                .catch(e => console.log(e));
        }
        return () => console.log("Far Galaxy unmounted");
    }, [openingCrawl]);


    return (<div>{(openingCrawl) && <p className={style.farGalaxy}>{openingCrawl}</p>}
    </div>)
}

export default FarGalaxy;