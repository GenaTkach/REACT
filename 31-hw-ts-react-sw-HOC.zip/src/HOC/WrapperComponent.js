import {useContext, useEffect} from "react";
import {HeroContext} from "../utils/HeroContext";
import {useNavigate, useParams} from "react-router-dom";
import {characters, defaultHero, navItems} from "../utils/constants";

export const Wrapper = WrappedComponent => function WrapperYo(props) {

    const {mainHero, setMainHero} = useContext(HeroContext);
    const navigate = useNavigate();
    const {heroName = ""} = useParams();


    useEffect(() => {
        if (!Object.keys(characters).includes(heroName)) {
            // Если нет, то показывай дефолтного героя, изменяем тут endpoint в браузере
            navigate(`/${props.route}/${defaultHero}`);
        } else {
            setMainHero(heroName);
        }
    }, [heroName]);

    return (
        <WrappedComponent setMainHero={setMainHero} mainHero={mainHero} {...props}/>
    );
}