import React from 'react';
import {textForStarWarsComponent} from "../../../utils/constants";
import {Wrapper} from "../../../HOC/WrapperComponent";

const StarWars = () => {

    return (
        <div>
            <p className="textForStarWarsComponent">{textForStarWarsComponent}</p>
        </div>
    );
};

export default Wrapper(StarWars);