import React, {useEffect, useState} from 'react';
import {characters, DAYS30INMILLISECONDS} from "../../../utils/constants";
import {Hero} from "../../../utils/types";
import {Wrapper} from "../../../HOC/WrapperComponent";

const BASE_URL = "https://sw-info-api.herokuapp.com/";

interface Props {
    mainHero: string;
    setMainHero: (mainHero: string) => void
}

const AboutMe = ({mainHero, setMainHero}: Props) => {

    const [hero, setHero] = useState<Hero>();

    useEffect(() => {
            // меняем контекст
            setMainHero(mainHero);
            const hero = JSON.parse(localStorage.getItem(mainHero)!);
            if (hero && ((Date.now() - hero.time) < DAYS30INMILLISECONDS)) {
                setHero(hero);
            } else {
                fetch(characters[mainHero].url)
                    .then(response => response.json())
                    .then(data => {
                        const requestHero = {
                            name: data.name,
                            birthYear: data.birth_year,
                            imgUrl: `${BASE_URL}${data.image}`,
                            gender: data.gender,
                            skin_color: data.skin_color,
                            hair_color: data.hair_color,
                            height: data.height,
                            eyeColor: data.eye_color,
                            mass: data.mass,

                            //Field for Falcon
                            consumables: data.consumables,
                            cargo_capacity: data.cargo_capacity,
                            passengers: data.passengers,
                            max_atmosphering_speed: data.max_atmosphering_speed,
                            crew: data.crew,
                            length: data.length,
                            manufacturer: data.manufacturer,
                        };
                        setHero(requestHero)
                        const heroJSON = JSON.stringify(requestHero)
                        localStorage.setItem(mainHero!, heroJSON);
                        localStorage.setItem("creationDateForAboutMe", Date.now().toString())

                    })
                    .catch(e => console.log(e));
            }
            return () => console.log("About Me unmounted")
        }, [mainHero]
    )

    return (
        <div>
            {(hero) && <div>
                {Object.entries(hero)
                    .map(([key, value]) => {
                        if (key === 'imgUrl') {
                            return <img className="img-fluid rounded  mx-auto" key={key} src={hero.imgUrl} alt="hero"/>
                        } else if (hero[key] === undefined) {
                        } else {
                            return <div key={key}>{key.toUpperCase()} : {value}</div>
                        }
                    })}
            </div>
            }
        </div>
    )
}

export default Wrapper(AboutMe);