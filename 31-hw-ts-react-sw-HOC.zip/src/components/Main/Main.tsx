import React from 'react';
import Home from "./Home/Home";
import {navItems} from "../../utils/constants";
import AboutMe from "./About Me/About Me";
import StarWars from "./StarWars/Star Wars";
import Contacts from "./Contacts/Contacts";
import {Route, Routes} from "react-router-dom";
import ErrorPage from "../Error Page/ErrorPage";

const Main = () => {

    return (
        <Routes>/
            <Route path="*" element={<ErrorPage/>}/>
            {["/", navItems[0].route, `${navItems[0].route}/:heroName`].map(p => <Route key={p} path={p}
                                                                                        element={<Home/>}/>)}
            {[navItems[1].route, `${navItems[1].route}/:heroName`].map(p => <Route key={p} path={p}
                                                                                 element={<AboutMe route={navItems[1].route}/>}/>)}
            {[navItems[2].route, `${navItems[2].route}/:heroName`].map(p => <Route key={p} path={p}
                                                                                   element={<StarWars route={navItems[2].route}/>}/>)}
            {[`${navItems[3].route}`, `${navItems[3].route}/:heroName`].map(p => <Route key={p} path={p}
                                                                                        element={<Contacts route={navItems[3].route}/>}/>)
            }
        </Routes>
    )
};

export default Main;