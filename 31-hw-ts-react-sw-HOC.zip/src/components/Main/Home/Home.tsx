import React from 'react';
import MainHero from "./MainHero/MainHero";
import DreamTeam from "./DreamTeam/DreamTeam";
import FarGalaxy from "./FarGalaxy/FarGalaxy";
import {navItems} from "../../../utils/constants";

const Home = () => {

    return (
        <main className="clearfix">
            <MainHero route={navItems[0].route}/>
            <DreamTeam/>
            <FarGalaxy/>
        </main>
    );
};

export default Home;