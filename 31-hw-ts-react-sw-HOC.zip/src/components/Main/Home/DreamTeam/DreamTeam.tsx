import React, {useContext} from 'react';
import {characters, imagesOfFriends} from "../../../../utils/constants";
import Friend from "./Friends/Friend";
import {HeroContext} from "../../../../utils/HeroContext";

const DreamTeam = () => {

    const {mainHero} = useContext(HeroContext);

    return (
        <section className="float-end w-50 row border mx-1 mt-1">
            <h2 className="col-12 text-center">Dream Team</h2>
            {Object.keys(characters).filter(element => element !== mainHero).map((name, index) =>
                <Friend name={name}
                        key={index}
                        pos={index + 1}
                        friend={characters[name].img}/>)}
        </section>
    );
};

export default DreamTeam;