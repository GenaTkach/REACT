import React, {useContext, useEffect} from 'react';
import main from "../../../../images/main.jpg";
import {useNavigate, useParams} from "react-router-dom";
import {characters, defaultHero, navItems} from "../../../../utils/constants";
import {HeroContext} from "../../../../utils/HeroContext";
import {Wrapper} from "../../../../HOC/WrapperComponent";

interface Props {
    mainHero: string
}

const MainHero = ({mainHero}:Props) => {

    return (
        <section className="float-start w-25 me-3">
            <img className="w-100" src={characters[mainHero].img} alt={characters[mainHero].name}/>
        </section>
    );
};

export default Wrapper(MainHero);