import {createSlice, PayloadAction} from "@reduxjs/toolkit";
import {UserProfile} from "../../utils/types"


const initialState: UserProfile | null = {
    login: "",
    firstName: "",
    lastName: "",
    roles: [],
};


const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        deleteUser: (state) => initialState,
        changeFirstName: (state, action) => {
            state.firstName = action.payload;
        },
        changeLastName: (state, action) => {
            state.lastName = action.payload;
        },
        changeLogin: (state, action) => {
            state.login = action.payload;
        },
        addRole: (state, action) => {
            state.roles.push(action.payload);
        },
        removeRole: (state, action) => {
            const index = state.roles.findIndex(action.payload);
            if (index > -1) {
                state.roles.splice(index, 1);
            }
        }
    }
})

export const {deleteUser, changeFirstName, changeLastName, changeLogin, addRole, removeRole} = userSlice.actions;
export default userSlice.reducer;