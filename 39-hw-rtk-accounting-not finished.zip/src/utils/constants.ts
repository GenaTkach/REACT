export const updateActions = new Map();
updateActions.set("edit", "editUser");
updateActions.set("change", "changePassword");
updateActions.set("", "");
