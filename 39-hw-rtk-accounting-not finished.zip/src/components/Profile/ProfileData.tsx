import React from 'react';

const ProfileData = () => {
    return (
        <div>
            <p>First name : ???</p>
            <p>Last name : ???</p>
            <ul>
                <li>User</li>
            </ul>
        </div>
    );
};

export default ProfileData;