import React, {useState} from 'react';
import EditUser from "./EditUser";
import ChangePassword from "./ChangePassword"
import {updateActions} from "../../utils/constants";

const UpdateUser = () => {

    const [updateAction, setUpdateAction] = useState("");

    switch (updateAction) {
        case updateActions.get("edit"):
            return <EditUser close={() => setUpdateAction("")}/>;
        case updateActions.get("change"):
            return <ChangePassword close={() => setUpdateAction("")}/>;
        default:
            return (
                <div>
                    <button onClick={() => setUpdateAction(updateActions.get("change"))}>Change password</button>
                    <button onClick={() => setUpdateAction(updateActions.get("edit"))}>Edit user profile</button>
                </div>
            );
    }
};

export default UpdateUser;