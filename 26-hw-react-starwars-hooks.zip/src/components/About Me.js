import React, {useEffect, useState} from 'react';
import {DAYS30INMILLISECONDS} from "../utils/constants";

const BASE_URL = "https://sw-info-api.herokuapp.com/";
const END_POINT = "v1/peoples/1"

const AboutMe = () => {

    const [hero, setHero] = useState(undefined);

    useEffect(() => {
        const localLyke = JSON.parse(localStorage.getItem('hero'));
        if (localLyke && Date.now() - localStorage.getItem("creationDateForAboutMe") < DAYS30INMILLISECONDS) {
            setHero(localLyke)
        } else {
            fetch(`${BASE_URL}${END_POINT}`)
                .then(response => response.json())
                .then(data => {
                    const requestHero = {
                        name: data.name,
                        birthYear: data.birth_year,
                        imgUrl: `${BASE_URL}${data.image}`,
                        gender: data.gender,
                        skin_color: data.skin_color,
                        hair_color: data.hair_color,
                        height: data.height,
                        eyeColor: data.eye_color,
                        mass: data.mass,
                    };
                    setHero(requestHero)
                    const heroJSON = JSON.stringify(requestHero)
                    localStorage.setItem('hero', heroJSON);
                    localStorage.setItem("creationDateForAboutMe", Date.now().toString())
                })
                .catch(e => console.log(e));
        }
        return () => console.log("About Me unmounted")
    }, [])

    return (
        <div>
            {(hero) && <div>
                {Object.entries(hero)
                    .map(([key, value]) => {
                        if (key === 'imgUrl') {
                            return <img key={key} src={hero.imgUrl} alt="hero"/>
                        } else {
                            return <div key={key}>{key.toUpperCase()} : {value}</div>
                        }
                    })}
            </div>
            }
        </div>
    )
}

export default AboutMe;