import React from "react";
import {defaultHero} from "./constants";
import {Context} from "./types";


export const HeroContext = React.createContext<Context>({
    mainHero: defaultHero, setMainHero: (hero: string) => {
    }
});
