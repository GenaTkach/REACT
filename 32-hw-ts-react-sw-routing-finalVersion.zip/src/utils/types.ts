export interface Hero {
    [key: string]: string
}

export interface Item {
    route: string;
    title: string;
}

export interface Character{
    name: string;
    img: string;
    url: string;
}

export interface Characters{
    [key: string]: Character;
}

export interface Context {
    mainHero: string;
    setMainHero: (hero: string) => void
}