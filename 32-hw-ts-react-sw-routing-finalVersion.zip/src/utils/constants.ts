import friend1 from "../images/friend1.jpg";
import friend2 from "../images/friend2.jpg";
import friend3 from "../images/friend3.jpg";
import friend4 from "../images/friend4.jpg";
import friend5 from "../images/friend5.jpg";
import friend6 from "../images/friend6.jpg";
import friend7 from "../images/friend7.jpg";
import friend8 from "../images/friend8.jpg";
import friend9 from "../images/friend9.jpg";
import {Characters, Item} from "./types";
import main from "../images/main.jpg";

export const imagesOfFriends = [friend1, friend2, friend3, friend4, friend5, friend6, friend7, friend8, friend9];

export const navItems: Item[] = [
    {
        route: "home",
        title: "Home"
    },
    {
        route: "about_me",
        title: "About me"
    },
    {
        route: "star_wars",
        title: "Star Wars"
    },
    {
        route: "contacts",
        title: "Contacts"
    },
];

export const textForStarWarsComponent = `Star Wars is a science fiction franchise that was created by filmmaker George Lucas in 1977 with the release of the first film, now known as Star Wars Episode IV: A New Hope. The franchise has since expanded to include numerous films, television shows, novels, comic books, video games, and other media.

The Star Wars universe is set in a distant galaxy and follows the adventures of a diverse cast of characters, including Jedi Knights, Sith Lords, smugglers, bounty hunters, and droids, among others. The story primarily revolves around the conflict between the Jedi, who are trained in the use of the Force, a mystical energy field that permeates the universe, and the Sith, who seek to use the Force for their own personal gain.

The original trilogy of films, which includes A New Hope, The Empire Strikes Back, and Return of the Jedi, focuses on the hero's journey of Luke Skywalker, a young farm boy who becomes a Jedi Knight and helps overthrow the evil Galactic Empire.

The prequel trilogy, which includes The Phantom Menace, Attack of the Clones, and Revenge of the Sith, takes place before the events of the original trilogy and explores the backstory of characters like Anakin Skywalker (who later becomes Darth Vader) and Obi-Wan Kenobi.

The sequel trilogy, which includes The Force Awakens, The Last Jedi, and The Rise of Skywalker, takes place after the events of the original trilogy and features a new cast of characters, including Rey, Finn, and Poe Dameron, as they battle the First Order, a new iteration of the Empire.

In addition to the films, the Star Wars franchise has also produced numerous television shows, including The Clone Wars, Rebels, and The Mandalorian, as well as an extensive collection of books, comics, and video games that expand on the Star Wars universe and its characters.`

export const DAYS30INMILLISECONDS = 2592000000;


export const base_url = 'http://sw-info-api.herokuapp.com';
export const version = '/v1';

export const characters: Characters = {
    luke: {
        name: "Luke Skywalker",
        img: main,
        url: `${base_url+version}/peoples/1`
    },
    c3po:{
        name: "C-3PO",
        img: friend2,
        url: `${base_url+version}/peoples/2`
    },
    r2d2:{
        name: "R2-D2",
        img: friend1,
        url: `${base_url+version}/peoples/3`
    },
    leia:{
        name: "Leia Organa",
        img: friend6,
        url: `${base_url+version}/peoples/5`
    },
    obi_wan:{
        name: "Obi-Wan Kenobi",
        img: friend8,
        url: `${base_url+version}/peoples/10`
    },
    chewbacca:{
        name: "Chewbacca",
        img: friend4,
        url: `${base_url+version}/peoples/13`
    },
    han_solo:{
        name: "Han Solo",
        img: friend5,
        url: `${base_url+version}/peoples/14`
    },
    yoda:{
        name: "Yoda",
        img: friend9,
        url: `${base_url+version}/peoples/0`
    },
    ewok:{
        name: "Wicket Systri Warrick",
        img: friend3,
        url: `${base_url+version}/peoples/30`
    },
    falcon:{
        name: "Millennium Falcon",
        img: friend7,
        url: `${base_url+version}/transports/10`
    }
};

export const defaultHero = Object.keys(characters)[0];