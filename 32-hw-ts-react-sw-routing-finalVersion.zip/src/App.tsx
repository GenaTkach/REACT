import React, {useState} from 'react';
import './App.css';
import Header from "./components/Header/Header";
import Main from "./components/Main/Main";
import Footer from "./components/Footer/Footer";
import {defaultHero} from "./utils/constants";
import {Item} from "./utils/types";
import {HeroContext} from "./utils/HeroContext";

function App() {

    const [hero, setHero] = useState(defaultHero);

    return (
        <div className="container-fluid">
            <HeroContext.Provider value={{mainHero:hero, setMainHero:setHero}}>
                <Header/>
                <Main/>
                <Footer/>
            </HeroContext.Provider>
        </div>
    );
}

export default App;
