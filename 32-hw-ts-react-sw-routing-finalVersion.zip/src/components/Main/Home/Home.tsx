import React, {useContext} from 'react';
import MainHero from "./MainHero/MainHero";
import DreamTeam from "./DreamTeam/DreamTeam";
import FarGalaxy from "./FarGalaxy/FarGalaxy";

const Home = () => {

    return (
        <main className="clearfix">
            <MainHero/>
            <DreamTeam/>
            <FarGalaxy/>
        </main>
    );
};

export default Home;