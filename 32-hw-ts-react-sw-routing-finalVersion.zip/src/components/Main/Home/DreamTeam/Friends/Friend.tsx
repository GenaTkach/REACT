import React, {useContext, useEffect} from 'react';
import style from "../../../../../css/bottom-around.module.css"
import {HeroContext} from "../../../../../utils/HeroContext";
import {defaultHero, navItems} from "../../../../../utils/constants";
import {useNavigate, useParams} from "react-router-dom";
import onHoverStyle from "../../../../../css/Friends-onHover.module.css"


interface Props {
    name: string;
    friend: string;
    pos: number;
}

const Friend = ({name, friend, pos}: Props) => {

    const {setMainHero} = useContext(HeroContext);
    const navigate = useNavigate();


    let styles = 'col-4 p-1 ';
    if (pos === 7) {
        styles += style.bottomLeft + " ";
    }
    if (pos === 9) {
        styles += style.bottomRight + " ";
    }
    return (
        <img
            onMouseOver={(event) => event.currentTarget.className += style.hover}
            onMouseLeave={(event) => event.currentTarget.className = styles}
            onClick={() => {
                //меняем главного героя
                setMainHero(name);
                //меняем адресную строку и добавляем нового главного героя
                navigate(`/${navItems[0].route}/${name}`)
            }}
            className={styles}
            src={friend}
            alt="friend"/>
    );
};

export default Friend;