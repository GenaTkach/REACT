import React, {useContext} from 'react';
import {characters, imagesOfFriends} from "../../../../utils/constants";
import Friend from "./Friends/Friend";
import {HeroContext} from "../../../../utils/HeroContext";

const DreamTeam = () => {

    const {mainHero} = useContext(HeroContext);
    const charactersWithoutMainHero = Object.keys(characters);
    const index = charactersWithoutMainHero.findIndex(e => e === mainHero)
    charactersWithoutMainHero.splice(index, 1)

    return (
        <section className="float-end w-50 row border mx-1 mt-1">
            <h2 className="col-12 text-center">Dream Team</h2>
            {charactersWithoutMainHero.map((name, index) => <Friend name={name} key={index} pos={index + 1}
                                                               friend={characters[name].img}/>)}
        </section>
    );
};

export default DreamTeam;