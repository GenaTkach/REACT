import React, {useContext, useEffect} from 'react';
import main from "../../../../images/main.jpg";
import {useParams} from "react-router-dom";
import {characters, defaultHero} from "../../../../utils/constants";
import {HeroContext} from "../../../../utils/HeroContext";

const MainHero = () => {

    const {heroName = defaultHero} = useParams();
    const {mainHero,setMainHero} = useContext(HeroContext);

    useEffect(() => {
        setMainHero(heroName);
    },[])

    return (
            <section className="float-start w-25 me-3">
                <img className="w-100" src={characters[mainHero].img} alt={characters[mainHero].name}/>
            </section>
    );
};

export default MainHero;