import React, {useContext, useEffect} from 'react';
import {characters, navItems, textForStarWarsComponent} from "../../../utils/constants";
import {useNavigate, useParams} from "react-router-dom";
import {HeroContext} from "../../../utils/HeroContext";

const StarWars = () => {

    const {mainHero} = useContext(HeroContext);
    const navigate = useNavigate();
    const {heroName} = useParams();

    useEffect(() => {
            if (!Object.keys(characters).includes(heroName!)) {
                navigate(`/${navItems[2].route}/${mainHero}`)
            }
        }
    )


    return (
        <div>
            <p className="textForStarWarsComponent">{textForStarWarsComponent}</p>
        </div>
    );
};

export default StarWars;