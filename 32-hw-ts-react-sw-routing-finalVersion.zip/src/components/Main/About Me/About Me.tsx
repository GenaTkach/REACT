import React, {useContext, useEffect, useState} from 'react';
import {characters, DAYS30INMILLISECONDS, defaultHero, navItems} from "../../../utils/constants";
import {Hero} from "../../../utils/types";
import {useNavigate, useParams} from "react-router-dom";
import {HeroContext} from "../../../utils/HeroContext";

const BASE_URL = "https://sw-info-api.herokuapp.com/";

const AboutMe = () => {

    const [hero, setHero] = useState<Hero>();
    let {heroId = ''} = useParams();
    const navigate = useNavigate();
    const {setMainHero: changeHero} = useContext(HeroContext);


    useEffect(() => {
            // Проверка, что такой heroId есть в characters
            if (!Object.keys(characters).includes(heroId)) {
                // Если нет, то показывай дефолтного героя, изменяем тут endpoint в браузере
                navigate(`/${navItems[1].route}/${defaultHero}`)
            } else {
                // меняем контекст
                changeHero(heroId);
                const hero = JSON.parse(localStorage.getItem(heroId)!);
                if (hero && ((Date.now() - hero.time) < DAYS30INMILLISECONDS)) {
                    setHero(hero);
                } else {
                    fetch(characters[heroId].url)
                        .then(response => response.json())
                        .then(data => {
                            const requestHero = {
                                name: data.name,
                                birthYear: data.birth_year,
                                imgUrl: `${BASE_URL}${data.image}`,
                                gender: data.gender,
                                skin_color: data.skin_color,
                                hair_color: data.hair_color,
                                height: data.height,
                                eyeColor: data.eye_color,
                                mass: data.mass,

                                //Field for Falcon
                                consumables: data.consumables,
                                cargo_capacity: data.cargo_capacity,
                                passengers: data.passengers,
                                max_atmosphering_speed: data.max_atmosphering_speed,
                                crew: data.crew,
                                length: data.length,
                                manufacturer: data.manufacturer,
                            };
                            setHero(requestHero)
                            const heroJSON = JSON.stringify(requestHero)
                            localStorage.setItem(heroId!, heroJSON);
                            localStorage.setItem("creationDateForAboutMe", Date.now().toString())

                        })
                        .catch(e => console.log(e));
                }
            }
            return () => console.log("About Me unmounted")
        }, [heroId]
    )

    return (
        <div>
            {(hero) && <div>
                {Object.entries(hero)
                    .map(([key, value]) => {
                        if (key === 'imgUrl') {
                            return <img className="img-fluid rounded  mx-auto" key={key} src={hero.imgUrl} alt="hero"/>
                        } else if (hero[key] === undefined) {
                        } else {
                            return <div key={key}>{key.toUpperCase()} : {value}</div>
                        }
                    })}
            </div>
            }
        </div>
    )
}

export default AboutMe;