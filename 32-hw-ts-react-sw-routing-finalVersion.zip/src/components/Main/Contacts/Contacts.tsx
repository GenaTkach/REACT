import React, {useContext, useEffect, useState} from 'react';
import {characters, DAYS30INMILLISECONDS, navItems} from "../../../utils/constants";
import {useNavigate, useParams} from "react-router-dom";
import {HeroContext} from "../../../utils/HeroContext";

interface Planet {
    name: string;
}

const Contacts = () => {

    const [planets, setPlanets] = useState(['loading...'])
    const {mainHero} = useContext(HeroContext);
    const {heroName} = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        if(!Object.keys(characters).includes(heroName!)){
            navigate(`/${navItems[3].route}/${mainHero}`)
        }
        const planets = JSON.parse(localStorage.getItem('planets') as string);
        if (planets && Date.now() - (+localStorage.getItem("creationDateForContacts")!) < DAYS30INMILLISECONDS) {
            setPlanets(planets);
        } else {
            fetch(`https://sw-info-api.herokuapp.com/v1/planets`)
                .then(response => response.json())
                .then((data:Planet[]) => data.map(d => d.name))
                .then(planets => {
                        setPlanets(planets);
                        localStorage.setItem("planets", JSON.stringify(planets))
                        localStorage.setItem("creationDateForContacts", Date.now().toString())
                    }
                )
                .catch(e => console.log(e));
        }
        return () => console.log("Contacts unmounted")
    }, [])


    return (<div>
        <form>
            <label>First Name</label>
            <input type="text" placeholder="Your name.."/>
            <br/>

            <label>Last Name</label>
            <input type="text" placeholder="Your last name.."/>
            <br/>

            <label>Planet</label>
            <select>
                {planets.map(planet => <option
                    key={planet}>{planet}</option>)}
            </select>
            <br/>

        </form>
    </div>);
}

export default Contacts;