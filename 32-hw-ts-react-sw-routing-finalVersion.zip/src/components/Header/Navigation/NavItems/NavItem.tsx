import React, {useContext} from 'react';
import {Item} from "../../../../utils/types";
import {Link} from "react-router-dom";
import {HeroContext} from "../../../../utils/HeroContext";

interface Props {
    content: Item;
}

const NavItem = ({content}: Props) => {

    const {mainHero} = useContext(HeroContext);

    return (
        <li>
            <Link className="nav-item btn btn-danger mx-1" to={`${content.route}/${mainHero}`}>{content.title}</Link>
        </li>
    );
};

export default NavItem;