import {createSlice} from "@reduxjs/toolkit";

const weatherSlice = createSlice({
    name: 'weather',
    initialState: {
        country: '',
        city: '',
        temp: 0,
        pressure: 0,
        sunset: 0,
    },
    reducers: {
        putWeather(state, action){
            return action.payload;
        }
    }
})

export const {putWeather} = weatherSlice.actions;
export default weatherSlice.reducer;