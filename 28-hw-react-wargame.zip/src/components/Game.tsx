import React, {useState} from 'react';
import {getShuffledCards} from "../utils/constants";
import Card from "./Card";

interface Props {
    playerName: string;
    whoWins: (wonRoundsComp: number, wonRoundsUser: number) => void
}

interface Card {
    value: string,
    suit: string,
    rank: number
}

const Game = ({playerName, whoWins}: Props) => {

    const [count, setCount] = useState(0);

    const [countWinsComp, setCountWinsComp] = useState(0);
    const [countWinsUser, setCountWinsUser] = useState(0);


    const array = getShuffledCards();
    const computerCards = array.slice(0, 26);
    const userCards = array.slice(-26);


    const nextHandleClick = () => {
        if (count < 25) {
            const res = compareCards(computerCards[count]!, userCards[count]!);
            if (res === "user") {
                setCountWinsUser(prevState => prevState + 1);
                document.getElementById('user-card')!.classList.add('winner');
                setTimeout(() => {
                    document.getElementById('user-card')!.classList.remove('winner');
                }, 200);
            } else if (res === "comp") {
                setCountWinsComp(prevState => prevState + 1);
                document.getElementById('comp-card')!.classList.add('winner');
                setTimeout(() => {
                    document.getElementById('comp-card')!.classList.remove('winner');
                }, 200);
            } else {
                document.getElementById('comp-card')!.classList.add('draw');
                setTimeout(() => {
                    document.getElementById('comp-card')!.classList.remove('draw');
                }, 200);
                document.getElementById('user-card')!.classList.add('draw');
                setTimeout(() => {
                    document.getElementById('user-card')!.classList.remove('draw');
                }, 200);
            }
            setCount(prevState => prevState + 1)
        } else {
            whoWins(countWinsComp, countWinsUser);
            setCount(0);
            setCountWinsComp(0);
            setCountWinsUser(0);
        }


    }

    const compareCards = (obj1: Card, obj2: Card): string => {
        if (obj1.rank < obj2.rank) {
            return "user";
        } else if (obj1.rank > obj2.rank) {
            return "comp";
        } else {
            return "draw";
        }
    }

    return (
        <div>
            <h1 className="p-3 mb-2 bg-primary text-white text-center">Computer</h1>
            <div className="d-flex justify-content-around m-2">
                <h3 className="mt-5">wins - {countWinsComp}</h3>
                <Card id="comp-card" card={computerCards[count]}/>
                <br/>
                <button className="btn btn-success mx-3" onClick={nextHandleClick}>NEXT</button>
                <br/><br/>
                <Card id="user-card" card={userCards[count]}/>
                <h3 className="mt-5">wins - {countWinsUser}</h3>
            </div>
            <h1 className="p-3 mb-2 bg-primary text-white text-center">{playerName}</h1>
            <h2 className="text-center">Round {count + 1}</h2>
        </div>
    );
};

export default Game;