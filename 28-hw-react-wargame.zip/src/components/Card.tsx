import React from "react";

interface Props {
    card: {
        value: string;
        suit: string;
    };
    id: string;
}

const Card = ({card, id}: Props) => {
    return (
        <div id={id} className="card">
            <div>{card.value}</div>
            <div>{card.suit}</div>
        </div>
    );
};

export default Card;
