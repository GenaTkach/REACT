import React, {Dispatch, SetStateAction, useEffect, useState} from 'react';

interface Props {
    winner: string;
    restartGame: (arg: string) => void

    exitGame: () => void
    prevGames: number[];
    setResult: Dispatch<SetStateAction<number[]>>
}

const Result = ({winner, restartGame, exitGame, prevGames, setResult}: Props) => {


    useEffect(() => {
        const array = {...prevGames};
        if (winner === "user") {
            array[0] += 1;
        } else if (winner === "computer") {
            array[1] += 1;
        } else {
            array[2] += 1;
        }
        setResult(array);
    }, [winner]);

    const clickHandlerRestartTheGame = (): void => {
        restartGame("nobody");
    }

    const clickHandlerExitTheGame = () => {
        exitGame();
    }

    return (
        <div className="p-3 mb-2 bg-primary text-white text-center">
            Win \ Lose \Draw
            <div>
                {prevGames[0]}-{prevGames[1]}-{prevGames[2]}
            </div>
            <br></br>
            <button className="btn btn-success" onClick={clickHandlerRestartTheGame}>Again?</button>
            <button className="btn btn-danger" onClick={clickHandlerExitTheGame}>Exit</button>
        </div>
    );
};

export default Result;