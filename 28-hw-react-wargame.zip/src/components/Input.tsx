import React, {ChangeEvent, useState} from 'react';
import {Simulate} from "react-dom/test-utils";
import input = Simulate.input;

interface Props {
    setName: (name: string) => void;

}

const Input = ({setName}:Props) => {

    const [playerName, setPlayerName] = useState("");

    const handleClick = () => {
        setPlayerName("")
        setName(playerName);
    }

    const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
        setPlayerName(e.target.value);
    }

    return (
        <div className="p-3 mb-2 bg-primary text-white text-center">
            <h1>Ready for WAR</h1>
            <input
                onChange={handleChange}
                type={"text"}
                value={playerName}
                placeholder={"Enter your name"}/>
            <button className="btn btn-sm btn-dark"
                onClick={handleClick}
            >Start
            </button>
        </div>
    );
};

export default Input;