export const suits = ["spades", "diamonds", "clubs", "hearts"];
export const values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];

export const rank = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];

export const getShuffledCards = (): { value: string, suit: string, rank: number }[] => {
    const array: { value: string, suit: string, rank: number }[] = []
    for (let i = 0; i < suits.length; i++) {
        for (let j = 0; j < values.length; j++) {
            let card: { value: string, suit: string, rank: number } = {value: values[j], suit: suits[i], rank: rank[j]};
            array.push(card)
        }
    }
    const shuffleArray = require('shuffle-array');
    shuffleArray(array)
    return array;
}