import React, {useState} from 'react';
import './App.css';
import Input from "./components/Input";
import Game from "./components/Game"
import Result from "./components/Result";

function App() {

    const [playerName, setPlayerName] = useState("");
    const [winner, setWinner] = useState("nobody");
    const [prevGames, setResult] = useState([0, 0, 0]);


    const setName = (name: string) => {
        setPlayerName(name);
    }

    const whoWins = (wonRoundsComp: number, wonRoundsUser: number): void => {
        if (wonRoundsComp > wonRoundsUser) {
            setWinner("computer")
        } else if (wonRoundsComp < wonRoundsUser) {
            setWinner("user")
        } else {
            setWinner("draw");
        }
    }

    const restartGame = (nobodystr: string): void => {
        setWinner(nobodystr)
    }

    const exitGame = () => {
        setPlayerName("");
        setResult([0, 0, 0]);
        setWinner("nobody")
    }


    if (winner === "nobody" && playerName) {
        return (<Game whoWins={whoWins} playerName={playerName}/>)
    } else if (winner !== "nobody" && playerName) {
        return <Result prevGames={prevGames} setResult={setResult} restartGame={restartGame} winner={winner} exitGame={exitGame}/>
    } else {
        return <Input setName={setName}/>
    }
}

export default App;
