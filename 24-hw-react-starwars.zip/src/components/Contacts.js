import React from 'react';

class Contacts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            planets: []
        }
    }

    componentDidMount() {
        fetch(`https://sw-info-api.herokuapp.com/v1/planets`)
            .then(response => response.json())
            .then(data => data.forEach(d => this.state.planets.push(d.name), this.setState({isLoading: false})))
            .catch(e => console.log(e));
    }


    render() {
        if (this.state.isLoading) {
            return <div className="d-flex justify-content-center">
                <div className="spinner-grow text-warning m-3" role="status"></div>
            </div>
        } else {
            return (<div>
                <form>
                    <label>First Name</label>
                    <input type="text" placeholder="Your name.."/>
                    <br/>

                    <label>Last Name</label>
                    <input type="text" placeholder="Your last name.."/>
                    <br/>

                    <label>Planet</label>
                    <select>
                        {this.state.planets.map(planet => <option key={planet}>{planet}</option>)}
                    </select>
                    <br/>

                </form>
            </div>);
        }
    }
}

export default Contacts;