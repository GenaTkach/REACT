import React from 'react';
import {planets} from "../utils/constants";

const Contacts = () => {
    return (
        <div>
            <form>
                <label>First Name</label>
                <input type="text" placeholder="Your name.."/>
                <br/>

                <label>Last Name</label>
                <input type="text" placeholder="Your last name.."/>
                <br/>

                <label>Planet</label>
                <select>
                    {planets.map(planet => <option>{planet}</option>)}
                </select>
                <br/>

            </form>
        </div>
    );
};

export default Contacts;