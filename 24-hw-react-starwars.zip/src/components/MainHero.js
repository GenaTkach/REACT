import React from 'react';
import main from "../images/main.jpg";

const MainHero = () => {
    return (
            <section className="float-start w-25 me-3">
                <img className="w-100" src={main} alt="hero"/>
            </section>
    );
};

export default MainHero;