import React from 'react';

const BASE_URL = "https://sw-info-api.herokuapp.com/";
const END_POINT = "v1/films/"
const randomNumber = Math.floor(Math.random() * 6) + 1;


class FarGalaxy extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
        }
    }

    componentDidMount() {
        fetch(`${BASE_URL}${END_POINT}${randomNumber}`)
            .then(response => response.json())
            .then(data => this.setState({
                openingCrawl: {text: data.opening_crawl},
                isLoading: false
            }))
            .catch(e => console.log(e));
    }

    render() {
        if (this.state.isLoading) {
            return <div className="d-flex justify-content-center">
                <div className="spinner-grow text-warning m-3" role="status"></div>
            </div>
        } else {
            return (<p className="farGalaxy">{this.state.openingCrawl.text}</p>);
        }
    }
}

export default FarGalaxy;