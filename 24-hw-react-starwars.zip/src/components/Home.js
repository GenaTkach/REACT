import React from 'react';
import MainHero from "./MainHero";
import DreamTeam from "./DreamTeam";
import FarGalaxy from "./FarGalaxy";

const Home = () => {
    return (
        <main className="clearfix">
            <MainHero/>
            <DreamTeam/>
            <FarGalaxy/>
        </main>
    );
};

export default Home;