import React from 'react';

const BASE_URL = "https://sw-info-api.herokuapp.com/";
const END_POINT = "v1/peoples/1"

class AboutMe extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isLoading: true
        }
    }

    componentDidMount() {
        fetch(`${BASE_URL}${END_POINT}`)
            .then(response => response.json())
            .then(data => this.setState({
                isLoading: false,
                hero: {
                    name: data.name,
                    birthYear: data.birth_year,
                    imgUrl: `${BASE_URL}${data.image}`,
                    gender: data.gender,
                    skin_color: data.skin_color,
                    hair_color: data.hair_color,
                    height: data.height,
                    eye_color: data.eye_color,
                    mass: data.mass,
                },
            }))
    }


    render() {
        if (this.state.isLoading) {
            return <div className="d-flex justify-content-center">
                <div className="spinner-grow text-warning m-3" role="status"></div>
            </div>
        } else {
            return (
                <div>
                    <h1>Name: {this.state.hero.name}</h1>
                    <img src={this.state.hero.imgUrl}  alt="hero"/>

                    <h1>Birth year: {this.state.hero.birthYear}</h1>
                    <h1>Gender: {this.state.hero.gender}</h1>
                    <h1>Skin color: {this.state.hero.skin_color}</h1>
                    <h1>Hair color: {this.state.hero.hair_color}</h1>
                    <h1>Eye color: {this.state.hero.eye_color}</h1>
                    <h1>Height: {this.state.hero.height}</h1>
                    <h1>Mass: {this.state.hero.mass}</h1>


                </div>
            );
        }
    }
}

export default AboutMe;