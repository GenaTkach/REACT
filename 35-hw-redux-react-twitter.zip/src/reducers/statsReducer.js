import {CHANGE_FOLLOWERS, CHANGE_FOLLOWINGS} from "../actions/statsActions";

const defaultState = {
    followers: 10,
    followings: 15,
}

export const statsReducer = (state = defaultState, action) => {
    let res;
    switch (action.type) {
        case CHANGE_FOLLOWERS:
            res = state.followers + action.payload;
            return {
                ...state,
                followers: res >= 0 ? res : 0
            };
        case CHANGE_FOLLOWINGS:
            res = state.followings + action.payload;
            return {
                ...state,
                followings: res >= 0 ? res : 0
            };
        // Если подходящего type нет, то не меняем state
        default:
            return state;
    }
}