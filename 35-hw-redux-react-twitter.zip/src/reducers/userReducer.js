import {CHANGE_AVATAR, CHANGE_NAME} from "../actions/userActions";


const defaultState = {
    name: "Monster",
    avatar: "https://www.gravatar.com/avatar/0?d=wavatar"
}
export const userReducer = (state = defaultState, action) => {
    switch (action.type) {
        case CHANGE_NAME:
            return {...state, name: action.payload || state.name};
        case CHANGE_AVATAR:
            return {...state, avatar: action.payload || state.user.avatar};
        // Если подходящего type нет, то не меняем state
        default:
            return state;
    }
}