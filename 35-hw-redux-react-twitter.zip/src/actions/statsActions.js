import {CHANGE_AVATAR, CHANGE_NAME} from "./userActions";

export const CHANGE_FOLLOWERS = "CHANGE_FOLLOWERS";

export const CHANGE_FOLLOWINGS = "CHANGE_FOLLOWINGS";

export const changeFollowers = sum => (
    {
        type: CHANGE_FOLLOWERS,
        payload: sum
    }
)

export const changeFollowings = sum => (
    {
        type: CHANGE_FOLLOWINGS,
        payload: sum
    }
)