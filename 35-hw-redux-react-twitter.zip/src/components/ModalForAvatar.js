import React, {useContext, useState} from 'react';
import {avatars} from "../utils/constants";
import {useDispatch, useSelector} from "react-redux";
import {changeAvatar} from "../actions/userActions";


const ModalForAvatar = ({setShowModal}) => {
    const dispatch = useDispatch();

    const [selectedAvatar, setSelectedAvatar] = useState("");

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Choose avatar</h2>
                <select onChange={(event) => setSelectedAvatar(event.target.value)}>
                    {avatars.map(a => <option key={a} value={`https://www.gravatar.com/avatar/0?d=${a}`}>{a}</option>)}
                </select>
                <button className="btn btn-danger button" onClick={() => {
                    dispatch(changeAvatar(selectedAvatar));
                    setShowModal(false);
                }}>Save changes
                </button>
            </div>
        </div>
    );
};

export default ModalForAvatar;