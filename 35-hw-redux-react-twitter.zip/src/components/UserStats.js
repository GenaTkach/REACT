import React, {useState} from 'react';
import Avatar from "./Avatar";
import ModalForAvatar from './ModalForAvatar';
import ModalForChangeName from "./ModalForChangeName";
import {useDispatch, useSelector} from "react-redux";
import {changeFollowers, changeFollowings} from "../actions/statsActions";


const UserStats = () => {

    const dispatch = useDispatch();
    const {followers, followings} = useSelector(state => state.stats)
    const {name} = useSelector(state => state.user);

    const [showModalForAvatar, setShowModalForAvatar] = useState(false);
    const [showModalForChangeName, setShowModalForChangeName] = useState(false);


    const handleShowModalForAvatar = () => {
        setShowModalForAvatar(true);
    };

    function handleShowModalForChangeName() {
        setShowModalForChangeName(true);
    }

    if (showModalForAvatar) {
        return <ModalForAvatar setShowModal={setShowModalForAvatar}/>
    }


    if (showModalForChangeName) {
        return <ModalForChangeName setShowModal={setShowModalForChangeName}/>
    }

    return (<div className="user-stats">
        <div onContextMenu={(event) => {
            event.preventDefault();
            handleShowModalForAvatar();
        }}
             onClick={handleShowModalForChangeName}>
            <Avatar/>
            {name}
        </div>
        <div className="stats">
            <div
                onClick={() => {
                    dispatch(changeFollowers(-1))
                }}
                onContextMenu={(event) => {
                    dispatch(changeFollowers(1))
                    event.preventDefault();
                }}
            >Followers {followers}</div>

            <div onClick={() => dispatch(changeFollowings(-1))}
                 onContextMenu={(event) => {
                     event.preventDefault();
                     dispatch(changeFollowings(1));
                 }}>Following {followings}</div>
        </div>
    </div>);
};

export default UserStats;