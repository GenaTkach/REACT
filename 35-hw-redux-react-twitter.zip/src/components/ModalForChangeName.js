import React, {useContext, useState} from 'react';
import {avatars} from "../utils/constants";
import {useDispatch} from "react-redux";
import {changeName} from "../actions/userActions";


const ModalForChangeName = ({setShowModal}) => {
    const dispatch = useDispatch();
    const [newName, setNewName] = useState("");

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Change name</h2>
                <input onChange={(event) => setNewName(event.target.value)}></input>
                <button className="btn btn-danger button" onClick={() => {
                    dispatch(changeName(newName));
                    setShowModal(false);
                }}>Save changes
                </button>
            </div>
        </div>
    );
};

export default ModalForChangeName;