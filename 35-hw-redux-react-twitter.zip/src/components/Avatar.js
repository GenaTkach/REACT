import React, {useContext} from 'react';
import {useSelector} from "react-redux";


const Avatar = ({size}) => {

    const {name, avatar} = useSelector(state => state.user);

    return (
        <img className={`user-avatar ${size} ?? ""}`} src={avatar} alt={name}/>
    );
};

export default Avatar;